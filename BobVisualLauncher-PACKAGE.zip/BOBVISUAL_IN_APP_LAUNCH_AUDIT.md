# BobVisual in-app launch audit

## What the source implements

- The home screen's Play button calls `MainActivity.launchGame()` and `performActualLaunch()`.
- `MinecraftLauncher` and `MinecraftLoadingActivity` prepare and launch the selected version into this app's `MinecraftActivity` rather than starting the Android package manager or an external Minecraft app.
- `MinecraftActivity` is declared in the app manifest with `android:screenOrientation="sensorLandscape"`; portrait launch is only requested when the selected profile explicitly sets `LAUNCH_VERTICALLY`.
- APK/version import and per-version storage are implemented in the launcher source; this does not mean every APK is compatible.
- The application ID is `com.bobvisual.launcher`; Java/Kotlin namespace remains `org.levimc.launcher` to preserve existing class references.

## Fix made in this source bundle

- Added `app/src/main/res/drawable/bobvisual_logo.xml`, which was referenced by the adaptive launcher icon but absent from the supplied source tree. This fixes that specific missing-resource reference.
- Updated installation documentation to describe in-app APK import and avoid the contradictory statement that the separate Minecraft app must always be installed.

## Not yet verified

This environment does not have an Android SDK/NDK installation available, so no APK build or on-device launch test has been completed here. A CI build may reveal additional upstream dependency or configuration issues. Microsoft/Xbox sign-in may require OAuth setup for `com.bobvisual.launcher`.
