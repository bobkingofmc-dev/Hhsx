# BobVisual — build guide (Uzbek)

## Nima o‘zgardi
- Ilova nomi: **BobVisual**.
- Yangi package ID: `com.bobvisual.launcher`.
- Qora / binafsha / ko‘k ranglar va yangi B logotipi.
- Upstream LeviLaunchroid litsenziyasi va mualliflik bildirishnomalari saqlandi.

## APK olish
1. Ushbu source ZIP’ni o‘zingizning GitHub repository’ingizga yuklang.
2. GitHub → **Actions** bo‘limini oching.
3. **Android CI** workflow’ni tanlab, **Run workflow** bosing.
4. Build muvaffaqiyatli tugagach, run sahifasidagi **Artifacts** bo‘limidan `BobVisual-release-unsigned-apk` yoki `BobVisual-debug-apk` faylini yuklab oling.
5. Unsigned APK’ni o‘rnatishdan oldin Android’da ishonchli imzolash vositasi bilan imzolash kerak bo‘lishi mumkin.

## Muhim
- Bu loyiha Minecraft Bedrock uchun launcher; Minecraft o‘yin fayllari APK ichiga qo‘shilmagan.
- Ushbu forkda Google AdMob yoki boshqa haqiqiy reklama SDK’si sozlanmagan. Reklama qo‘shish uchun o‘zingizning reklama tarmog‘i hisobingiz va ad unit ID’lari kerak.
- Microsoft/Xbox login uchun o‘zingizning OAuth / redirect konfiguratsiyangiz talab qilinishi mumkin.
- Android SDK va NDK kerak bo‘lgani sababli bu muhitda APK’ni to‘liq kompilyatsiya qilish tasdiqlanmadi. GitHub Actions build natijasini tekshiring.
